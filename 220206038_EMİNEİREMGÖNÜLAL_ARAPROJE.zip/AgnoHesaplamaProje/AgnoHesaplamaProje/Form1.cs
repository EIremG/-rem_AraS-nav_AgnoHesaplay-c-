
using System.Data.SqlClient;
namespace AgnoHesaplamaProje
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        private void GirisYapBtn_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = null;

            try
            {
                baglanti = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=��renciler;Integrated Security=True");

                baglanti.Open();

                SqlCommand sqlKomut = new SqlCommand("SELECT ��renciId, ��renciSifre FROM ��renciler", baglanti);
                SqlDataReader sqlDR = sqlKomut.ExecuteReader();

                while (sqlDR.Read())
                {
                    string id = sqlDR[0].ToString();
                    string sifre = sqlDR[1].ToString();

                    richTextBox1.Text = richTextBox1.Text + "��renci ID:" + " " + id + " " + "Sifre: " + sifre + "\n";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Sql Cuery Hatas�" + ex.ToString());
            }

            finally
            {
                if (baglanti != null)
                    baglanti.Close();


            }

        }

        private void Giri�Yap_Click(object sender, EventArgs e)
        {
            string girilenId = txtStudentId.Text;
            string girilenSifre = txtPassword.Text;


            foreach (string satir in richTextBox1.Lines)
            {
                string[] parcalar = satir.Split(' ');
                if (parcalar.Length >= 4)
                {
                    string id = parcalar[2];
                    string sifre = parcalar[4];


                    if (girilenId == id && girilenSifre == sifre)
                    {

                        Form2 form2 = new Form2();
                        form2.Show();
                        return;
                    }
                }
            }


            MessageBox.Show("��renci bilgileri e�le�medi. L�tfen tekrar deneyin.");
        }
    }
}

