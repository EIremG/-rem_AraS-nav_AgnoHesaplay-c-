﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgnoHesaplamaProje
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            try
            {

                float vizeNotu = float.Parse(txtVizeNotu.Text);
                float finalNotu = float.Parse(txtFinalNotu.Text);
                float odevNotu = float.Parse(txtOdevNotu.Text);
                float vizeAgirligi = float.Parse(txtVizeAgirligi.Text);
                float finalAgirligi = float.Parse(txtFinalAgirligi.Text);
                float odevAgirligi = float.Parse(txtOdevAgirligi.Text);


                if ((vizeNotu + finalNotu + odevNotu < 0 || vizeNotu + finalNotu + odevNotu > 300) ||
                    (vizeAgirligi + finalAgirligi + odevAgirligi != 100))
                {
                    throw new Exception("Hata: Notların toplamı en fazla 300 ve ağırlıkların toplamı 100 olmalı.");
                }

                if (vizeNotu > 100 || finalNotu > 100 || odevNotu > 100)
                {
                    throw new Exception("Hata: Notların değeri 100`ü geçmemeli.");
                }


                float agno = (vizeNotu * vizeAgirligi / 100) + (finalNotu * finalAgirligi / 100) + (odevNotu * odevAgirligi / 100);


                string harfNotu = HarfNotunuBelirle(agno);


                lblAGNO.Text = $"AGNO: {agno:F2}";
                lblHarfNotu.Text = $"Harf Notu: {harfNotu}";


                lblGeçmeDurumu.Text = GecmeDurumuBelirle(agno);

                lblYukseltmeDurumu.Text = YukseltmeDurumuBelirle(agno);



            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}. Lütfen uygun sayısal değerler girin.");
            }
        }

        private string HarfNotunuBelirle(float agno)
        {
            if (agno >= 90) return "AA";
            else if (agno >= 85) return "BA";
            else if (agno >= 80) return "BB";
            else if (agno >= 70) return "CB";
            else if (agno >= 60) return "CC";
            else if (agno >= 50) return "DC";
            else if (agno >= 45) return "DD";
            else if (agno >= 35) return "FD";
            else return "FF";
        }

        private string GecmeDurumuBelirle(float agno)
        {
            if (agno >= 50)
            {
                return "Geçti - Direk Geçiş";
            }
            else if (agno >= 45)
            {
                return "Geçti - Şartlı Geçiş (45)";
            }
            else
            {
                return "Geçemedi - Yükseltme İçin Dersi Vermelidir";
            }
        }

        private string YukseltmeDurumuBelirle(float agno)
        {
            if (agno >= 50 || (agno >= 45 && agno < 50))
            {
                return "Yükseltme Alabilir - Sonraki Sene İçerisinde Açılacaktır.";
            }
            else
            {
                return "Yükseltme Alamaz";
            }
        }
    }
}


