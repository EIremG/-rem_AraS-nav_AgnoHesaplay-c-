﻿namespace AgnoHesaplamaProje
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtStudentId = new TextBox();
            txtPassword = new TextBox();
            label2 = new Label();
            label3 = new Label();
            GirisYapBtn = new Button();
            richTextBox1 = new RichTextBox();
            GirişYap = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(438, 24);
            label1.Name = "label1";
            label1.Size = new Size(350, 80);
            label1.TabIndex = 1;
            label1.Text = "Yandaki listeden öğrenci numaranızı ve şifrenizi\r\nbulup sisteme giriş yapınız\r\n\r\nID ve şifreleri görmek için butona tıklayın\r\n";
            // 
            // txtStudentId
            // 
            txtStudentId.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtStudentId.Location = new Point(204, 259);
            txtStudentId.Name = "txtStudentId";
            txtStudentId.Size = new Size(204, 30);
            txtStudentId.TabIndex = 2;
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(204, 349);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(204, 30);
            txtPassword.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(63, 262);
            label2.Name = "label2";
            label2.Size = new Size(104, 22);
            label2.TabIndex = 4;
            label2.Text = "Öğrenci ID:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(63, 352);
            label3.Name = "label3";
            label3.Size = new Size(123, 22);
            label3.TabIndex = 5;
            label3.Text = "Öğrenci Şifre:";
            // 
            // GirisYapBtn
            // 
            GirisYapBtn.BackColor = Color.PowderBlue;
            GirisYapBtn.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            GirisYapBtn.Location = new Point(481, 121);
            GirisYapBtn.Name = "GirisYapBtn";
            GirisYapBtn.Size = new Size(241, 102);
            GirisYapBtn.TabIndex = 6;
            GirisYapBtn.Text = "ID ve Şifre Gör";
            GirisYapBtn.UseVisualStyleBackColor = false;
            GirisYapBtn.Click += GirisYapBtn_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(12, 12);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(396, 211);
            richTextBox1.TabIndex = 7;
            richTextBox1.Text = "";
            // 
            // GirişYap
            // 
            GirişYap.BackColor = Color.PowderBlue;
            GirişYap.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            GirişYap.Location = new Point(481, 259);
            GirişYap.Name = "GirişYap";
            GirişYap.Size = new Size(241, 120);
            GirişYap.TabIndex = 8;
            GirişYap.Text = "Giriş Yap";
            GirişYap.UseVisualStyleBackColor = false;
            GirişYap.Click += GirişYap_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(GirişYap);
            Controls.Add(richTextBox1);
            Controls.Add(GirisYapBtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtPassword);
            Controls.Add(txtStudentId);
            Controls.Add(label1);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Giriş Ekranı";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox txtStudentId;
        private TextBox txtPassword;
        private Label label2;
        private Label label3;
        private Button GirisYapBtn;
        private RichTextBox richTextBox1;
        private Button GirişYap;
    }
}