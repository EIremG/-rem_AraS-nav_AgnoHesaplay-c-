﻿namespace AgnoHesaplamaProje
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            label5 = new Label();
            txtVizeAgirligi = new TextBox();
            txtQuizAgirligi = new TextBox();
            txtFinalAgirligi = new TextBox();
            txtQuizNotu = new TextBox();
            lblYukseltmeDurumu = new Label();
            lblGeçmeDurumu = new Label();
            lblHarfNotu = new Label();
            lblAGNO = new Label();
            btnHesapla = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtFinalNotu = new TextBox();
            txtVizeNotu = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(569, 195);
            label6.Name = "label6";
            label6.Size = new Size(97, 20);
            label6.TabIndex = 48;
            label6.Text = "Quiz Ağırlığı";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(569, 43);
            label5.Name = "label5";
            label5.Size = new Size(88, 20);
            label5.TabIndex = 47;
            label5.Text = "Quiz Notu:";
            // 
            // txtVizeAgirligi
            // 
            txtVizeAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeAgirligi.Location = new Point(77, 218);
            txtVizeAgirligi.Name = "txtVizeAgirligi";
            txtVizeAgirligi.Size = new Size(188, 28);
            txtVizeAgirligi.TabIndex = 46;
            // 
            // txtQuizAgirligi
            // 
            txtQuizAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtQuizAgirligi.Location = new Point(526, 218);
            txtQuizAgirligi.Name = "txtQuizAgirligi";
            txtQuizAgirligi.Size = new Size(190, 28);
            txtQuizAgirligi.TabIndex = 45;
            // 
            // txtFinalAgirligi
            // 
            txtFinalAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalAgirligi.Location = new Point(297, 218);
            txtFinalAgirligi.Name = "txtFinalAgirligi";
            txtFinalAgirligi.Size = new Size(191, 28);
            txtFinalAgirligi.TabIndex = 44;
            // 
            // txtQuizNotu
            // 
            txtQuizNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtQuizNotu.Location = new Point(526, 66);
            txtQuizNotu.Name = "txtQuizNotu";
            txtQuizNotu.Size = new Size(190, 28);
            txtQuizNotu.TabIndex = 43;
            // 
            // lblYukseltmeDurumu
            // 
            lblYukseltmeDurumu.AutoSize = true;
            lblYukseltmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblYukseltmeDurumu.Location = new Point(297, 413);
            lblYukseltmeDurumu.Name = "lblYukseltmeDurumu";
            lblYukseltmeDurumu.Size = new Size(107, 20);
            lblYukseltmeDurumu.TabIndex = 42;
            lblYukseltmeDurumu.Text = "Bilgilendirme:";
            // 
            // lblGeçmeDurumu
            // 
            lblGeçmeDurumu.AutoSize = true;
            lblGeçmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblGeçmeDurumu.Location = new Point(297, 379);
            lblGeçmeDurumu.Name = "lblGeçmeDurumu";
            lblGeçmeDurumu.Size = new Size(118, 20);
            lblGeçmeDurumu.TabIndex = 41;
            lblGeçmeDurumu.Text = "Geçiş Durumu:";
            // 
            // lblHarfNotu
            // 
            lblHarfNotu.AutoSize = true;
            lblHarfNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblHarfNotu.Location = new Point(297, 340);
            lblHarfNotu.Name = "lblHarfNotu";
            lblHarfNotu.Size = new Size(139, 20);
            lblHarfNotu.TabIndex = 40;
            lblHarfNotu.Text = "Dersin Harf Notu:";
            // 
            // lblAGNO
            // 
            lblAGNO.AutoSize = true;
            lblAGNO.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblAGNO.Location = new Point(297, 306);
            lblAGNO.Name = "lblAGNO";
            lblAGNO.Size = new Size(105, 20);
            lblAGNO.TabIndex = 39;
            lblAGNO.Text = "Ders Agnosu:";
            // 
            // btnHesapla
            // 
            btnHesapla.BackColor = Color.PowderBlue;
            btnHesapla.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnHesapla.Location = new Point(297, 260);
            btnHesapla.Name = "btnHesapla";
            btnHesapla.Size = new Size(191, 31);
            btnHesapla.TabIndex = 38;
            btnHesapla.Text = "Hesapla";
            btnHesapla.UseVisualStyleBackColor = false;
            btnHesapla.Click += btnHesapla_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(352, 195);
            label4.Name = "label4";
            label4.Size = new Size(102, 20);
            label4.TabIndex = 37;
            label4.Text = "Final Ağırlığı:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(126, 195);
            label3.Name = "label3";
            label3.Size = new Size(98, 20);
            label3.TabIndex = 36;
            label3.Text = "Vize Ağırlığı:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(352, 43);
            label2.Name = "label2";
            label2.Size = new Size(89, 20);
            label2.TabIndex = 35;
            label2.Text = "Final Notu:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(126, 43);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 34;
            label1.Text = "Vize Notu:";
            // 
            // txtFinalNotu
            // 
            txtFinalNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalNotu.Location = new Point(297, 66);
            txtFinalNotu.Name = "txtFinalNotu";
            txtFinalNotu.Size = new Size(200, 28);
            txtFinalNotu.TabIndex = 33;
            // 
            // txtVizeNotu
            // 
            txtVizeNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeNotu.Location = new Point(77, 66);
            txtVizeNotu.Name = "txtVizeNotu";
            txtVizeNotu.Size = new Size(188, 28);
            txtVizeNotu.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(12, 9);
            label7.Name = "label7";
            label7.Size = new Size(367, 20);
            label7.TabIndex = 49;
            label7.Text = "BİL 207 (1) 1.0 Sayısal Tasarım I dersini seçtiniz.";
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtVizeAgirligi);
            Controls.Add(txtQuizAgirligi);
            Controls.Add(txtFinalAgirligi);
            Controls.Add(txtQuizNotu);
            Controls.Add(lblYukseltmeDurumu);
            Controls.Add(lblGeçmeDurumu);
            Controls.Add(lblHarfNotu);
            Controls.Add(lblAGNO);
            Controls.Add(btnHesapla);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtFinalNotu);
            Controls.Add(txtVizeNotu);
            MaximizeBox = false;
            Name = "Form7";
            Text = "Seçilen Ders";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private Label label5;
        private TextBox txtVizeAgirligi;
        private TextBox txtQuizAgirligi;
        private TextBox txtFinalAgirligi;
        private TextBox txtQuizNotu;
        private Label lblYukseltmeDurumu;
        private Label lblGeçmeDurumu;
        private Label lblHarfNotu;
        private Label lblAGNO;
        private Button btnHesapla;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtFinalNotu;
        private TextBox txtVizeNotu;
        private Label label7;
    }
}