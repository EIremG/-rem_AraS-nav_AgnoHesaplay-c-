﻿namespace AgnoHesaplamaProje
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            label5 = new Label();
            txtVizeAgirligi = new TextBox();
            txtOdevAgirligi = new TextBox();
            txtFinalAgirligi = new TextBox();
            txtOdevNotu = new TextBox();
            lblYukseltmeDurumu = new Label();
            lblGeçmeDurumu = new Label();
            lblHarfNotu = new Label();
            lblAGNO = new Label();
            btnHesapla = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtFinalNotu = new TextBox();
            txtVizeNotu = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(571, 200);
            label6.Name = "label6";
            label6.Size = new Size(102, 20);
            label6.TabIndex = 48;
            label6.Text = "Ödev Ağırlığı";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(571, 48);
            label5.Name = "label5";
            label5.Size = new Size(93, 20);
            label5.TabIndex = 47;
            label5.Text = "Ödev Notu:";
            // 
            // txtVizeAgirligi
            // 
            txtVizeAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeAgirligi.Location = new Point(79, 223);
            txtVizeAgirligi.Name = "txtVizeAgirligi";
            txtVizeAgirligi.Size = new Size(188, 28);
            txtVizeAgirligi.TabIndex = 46;
            // 
            // txtOdevAgirligi
            // 
            txtOdevAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtOdevAgirligi.Location = new Point(528, 223);
            txtOdevAgirligi.Name = "txtOdevAgirligi";
            txtOdevAgirligi.Size = new Size(190, 28);
            txtOdevAgirligi.TabIndex = 45;
            // 
            // txtFinalAgirligi
            // 
            txtFinalAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalAgirligi.Location = new Point(299, 223);
            txtFinalAgirligi.Name = "txtFinalAgirligi";
            txtFinalAgirligi.Size = new Size(191, 28);
            txtFinalAgirligi.TabIndex = 44;
            // 
            // txtOdevNotu
            // 
            txtOdevNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtOdevNotu.Location = new Point(528, 71);
            txtOdevNotu.Name = "txtOdevNotu";
            txtOdevNotu.Size = new Size(190, 28);
            txtOdevNotu.TabIndex = 43;
            // 
            // lblYukseltmeDurumu
            // 
            lblYukseltmeDurumu.AutoSize = true;
            lblYukseltmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblYukseltmeDurumu.Location = new Point(299, 418);
            lblYukseltmeDurumu.Name = "lblYukseltmeDurumu";
            lblYukseltmeDurumu.Size = new Size(107, 20);
            lblYukseltmeDurumu.TabIndex = 42;
            lblYukseltmeDurumu.Text = "Bilgilendirme:";
            // 
            // lblGeçmeDurumu
            // 
            lblGeçmeDurumu.AutoSize = true;
            lblGeçmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblGeçmeDurumu.Location = new Point(299, 384);
            lblGeçmeDurumu.Name = "lblGeçmeDurumu";
            lblGeçmeDurumu.Size = new Size(118, 20);
            lblGeçmeDurumu.TabIndex = 41;
            lblGeçmeDurumu.Text = "Geçiş Durumu:";
            // 
            // lblHarfNotu
            // 
            lblHarfNotu.AutoSize = true;
            lblHarfNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblHarfNotu.Location = new Point(299, 345);
            lblHarfNotu.Name = "lblHarfNotu";
            lblHarfNotu.Size = new Size(139, 20);
            lblHarfNotu.TabIndex = 40;
            lblHarfNotu.Text = "Dersin Harf Notu:";
            // 
            // lblAGNO
            // 
            lblAGNO.AutoSize = true;
            lblAGNO.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblAGNO.Location = new Point(299, 311);
            lblAGNO.Name = "lblAGNO";
            lblAGNO.Size = new Size(105, 20);
            lblAGNO.TabIndex = 39;
            lblAGNO.Text = "Ders Agnosu:";
            // 
            // btnHesapla
            // 
            btnHesapla.BackColor = Color.PowderBlue;
            btnHesapla.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnHesapla.Location = new Point(299, 265);
            btnHesapla.Name = "btnHesapla";
            btnHesapla.Size = new Size(191, 31);
            btnHesapla.TabIndex = 38;
            btnHesapla.Text = "Hesapla";
            btnHesapla.UseVisualStyleBackColor = false;
            btnHesapla.Click += btnHesapla_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(354, 200);
            label4.Name = "label4";
            label4.Size = new Size(102, 20);
            label4.TabIndex = 37;
            label4.Text = "Final Ağırlığı:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(128, 200);
            label3.Name = "label3";
            label3.Size = new Size(98, 20);
            label3.TabIndex = 36;
            label3.Text = "Vize Ağırlığı:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(354, 48);
            label2.Name = "label2";
            label2.Size = new Size(89, 20);
            label2.TabIndex = 35;
            label2.Text = "Final Notu:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(128, 48);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 34;
            label1.Text = "Vize Notu:";
            // 
            // txtFinalNotu
            // 
            txtFinalNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalNotu.Location = new Point(299, 71);
            txtFinalNotu.Name = "txtFinalNotu";
            txtFinalNotu.Size = new Size(200, 28);
            txtFinalNotu.TabIndex = 33;
            // 
            // txtVizeNotu
            // 
            txtVizeNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeNotu.Location = new Point(79, 71);
            txtVizeNotu.Name = "txtVizeNotu";
            txtVizeNotu.Size = new Size(188, 28);
            txtVizeNotu.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(12, 9);
            label7.Name = "label7";
            label7.Size = new Size(463, 20);
            label7.TabIndex = 49;
            label7.Text = "YZL 215 (2) 1.0 Nesneye Dayalı Programlama dersini seçtiniz.";
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(txtVizeAgirligi);
            Controls.Add(txtOdevAgirligi);
            Controls.Add(txtFinalAgirligi);
            Controls.Add(txtOdevNotu);
            Controls.Add(lblYukseltmeDurumu);
            Controls.Add(lblGeçmeDurumu);
            Controls.Add(lblHarfNotu);
            Controls.Add(lblAGNO);
            Controls.Add(btnHesapla);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtFinalNotu);
            Controls.Add(txtVizeNotu);
            MaximizeBox = false;
            Name = "Form8";
            Text = "Seçilen Ders";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private Label label5;
        private TextBox txtVizeAgirligi;
        private TextBox txtOdevAgirligi;
        private TextBox txtFinalAgirligi;
        private TextBox txtOdevNotu;
        private Label lblYukseltmeDurumu;
        private Label lblGeçmeDurumu;
        private Label lblHarfNotu;
        private Label lblAGNO;
        private Button btnHesapla;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtFinalNotu;
        private TextBox txtVizeNotu;
        private Label label7;
    }
}