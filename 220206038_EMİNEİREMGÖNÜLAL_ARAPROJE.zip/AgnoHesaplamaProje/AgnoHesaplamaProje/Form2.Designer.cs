﻿namespace AgnoHesaplamaProje
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            show4rdform = new Button();
            show3rdform = new Button();
            show5thform = new Button();
            show6thform = new Button();
            show7thform = new Button();
            show8thform = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            SuspendLayout();
            // 
            // show4rdform
            // 
            show4rdform.BackColor = Color.PowderBlue;
            show4rdform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show4rdform.Location = new Point(26, 97);
            show4rdform.Name = "show4rdform";
            show4rdform.Size = new Size(201, 54);
            show4rdform.TabIndex = 1;
            show4rdform.Text = "Dersi Göster";
            show4rdform.UseVisualStyleBackColor = false;
            show4rdform.Click += show4rdform_Click;
            // 
            // show3rdform
            // 
            show3rdform.BackColor = Color.PowderBlue;
            show3rdform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show3rdform.Location = new Point(26, 27);
            show3rdform.Name = "show3rdform";
            show3rdform.Size = new Size(201, 54);
            show3rdform.TabIndex = 2;
            show3rdform.Text = "Dersi Göster";
            show3rdform.UseVisualStyleBackColor = false;
            show3rdform.Click += show3rdform_Click;
            // 
            // show5thform
            // 
            show5thform.BackColor = Color.PowderBlue;
            show5thform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show5thform.Location = new Point(26, 166);
            show5thform.Name = "show5thform";
            show5thform.Size = new Size(201, 54);
            show5thform.TabIndex = 3;
            show5thform.Text = "Dersi Göster";
            show5thform.UseVisualStyleBackColor = false;
            show5thform.Click += show5thform_Click;
            // 
            // show6thform
            // 
            show6thform.BackColor = Color.PowderBlue;
            show6thform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show6thform.Location = new Point(26, 235);
            show6thform.Name = "show6thform";
            show6thform.Size = new Size(201, 54);
            show6thform.TabIndex = 4;
            show6thform.Text = "Dersi Göster";
            show6thform.UseVisualStyleBackColor = false;
            show6thform.Click += show6thform_Click;
            // 
            // show7thform
            // 
            show7thform.BackColor = Color.PowderBlue;
            show7thform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show7thform.Location = new Point(26, 306);
            show7thform.Name = "show7thform";
            show7thform.Size = new Size(201, 54);
            show7thform.TabIndex = 5;
            show7thform.Text = "Dersi Göster";
            show7thform.UseVisualStyleBackColor = false;
            show7thform.Click += show7thform_Click;
            // 
            // show8thform
            // 
            show8thform.BackColor = Color.PowderBlue;
            show8thform.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            show8thform.Location = new Point(26, 375);
            show8thform.Name = "show8thform";
            show8thform.Size = new Size(201, 54);
            show8thform.TabIndex = 6;
            show8thform.Text = "Dersi Göster";
            show8thform.UseVisualStyleBackColor = false;
            show8thform.Click += show8thform_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(275, 43);
            label1.Name = "label1";
            label1.Size = new Size(418, 22);
            label1.TabIndex = 7;
            label1.Text = "ATA 101 (2) 1.0 Atatürk İlkeleri ve İnkılap Tarihi I ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(275, 113);
            label2.Name = "label2";
            label2.Size = new Size(348, 22);
            label2.TabIndex = 8;
            label2.Text = "YZL 213 (2) 1.0 Ayrık Hesaplama Yapıları";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(275, 182);
            label3.Name = "label3";
            label3.Size = new Size(345, 22);
            label3.TabIndex = 9;
            label3.Text = "MAT 202 (1) 1.0 Diferansiyel Denklemler";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(275, 251);
            label4.Name = "label4";
            label4.Size = new Size(233, 22);
            label4.TabIndex = 10;
            label4.Text = "TUR 101 (1) 1.0 Türk Dili I";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(275, 322);
            label5.Name = "label5";
            label5.Size = new Size(276, 22);
            label5.TabIndex = 11;
            label5.Text = "BİL 207 (1) 1.0 Sayısal Tasarım I";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(275, 391);
            label6.Name = "label6";
            label6.Size = new Size(344, 22);
            label6.TabIndex = 12;
            label6.Text = "215 (2) 1.0 Nesneye Dayalı Programlama ";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(show8thform);
            Controls.Add(show7thform);
            Controls.Add(show6thform);
            Controls.Add(show5thform);
            Controls.Add(show3rdform);
            Controls.Add(show4rdform);
            MinimizeBox = false;
            Name = "Form2";
            Text = "Ders Ekranı";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button show4rdform;
        private Button show3rdform;
        private Button show5thform;
        private Button show6thform;
        private Button show7thform;
        private Button show8thform;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}