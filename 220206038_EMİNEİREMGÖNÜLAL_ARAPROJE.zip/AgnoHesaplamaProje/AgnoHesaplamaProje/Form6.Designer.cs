﻿namespace AgnoHesaplamaProje
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblYukseltmeDurumu = new Label();
            lblGeçmeDurumu = new Label();
            lblHarfNotu = new Label();
            lblAGNO = new Label();
            btnHesapla = new Button();
            txtFinalAgirligi = new TextBox();
            txtVizeAgirligi = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtFinalNotu = new TextBox();
            txtVizeNotu = new TextBox();
            label5 = new Label();
            SuspendLayout();
            // 
            // lblYukseltmeDurumu
            // 
            lblYukseltmeDurumu.AutoSize = true;
            lblYukseltmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblYukseltmeDurumu.Location = new Point(301, 408);
            lblYukseltmeDurumu.Name = "lblYukseltmeDurumu";
            lblYukseltmeDurumu.Size = new Size(107, 20);
            lblYukseltmeDurumu.TabIndex = 25;
            lblYukseltmeDurumu.Text = "Bilgilendirme:";
            // 
            // lblGeçmeDurumu
            // 
            lblGeçmeDurumu.AutoSize = true;
            lblGeçmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblGeçmeDurumu.Location = new Point(301, 374);
            lblGeçmeDurumu.Name = "lblGeçmeDurumu";
            lblGeçmeDurumu.Size = new Size(118, 20);
            lblGeçmeDurumu.TabIndex = 24;
            lblGeçmeDurumu.Text = "Geçiş Durumu:";
            // 
            // lblHarfNotu
            // 
            lblHarfNotu.AutoSize = true;
            lblHarfNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblHarfNotu.Location = new Point(301, 335);
            lblHarfNotu.Name = "lblHarfNotu";
            lblHarfNotu.Size = new Size(139, 20);
            lblHarfNotu.TabIndex = 23;
            lblHarfNotu.Text = "Dersin Harf Notu:";
            // 
            // lblAGNO
            // 
            lblAGNO.AutoSize = true;
            lblAGNO.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblAGNO.Location = new Point(301, 301);
            lblAGNO.Name = "lblAGNO";
            lblAGNO.Size = new Size(105, 20);
            lblAGNO.TabIndex = 22;
            lblAGNO.Text = "Ders Agnosu:";
            // 
            // btnHesapla
            // 
            btnHesapla.BackColor = Color.PowderBlue;
            btnHesapla.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnHesapla.Location = new Point(301, 255);
            btnHesapla.Name = "btnHesapla";
            btnHesapla.Size = new Size(191, 31);
            btnHesapla.TabIndex = 21;
            btnHesapla.Text = "Hesapla";
            btnHesapla.UseVisualStyleBackColor = false;
            btnHesapla.Click += btnHesapla_Click;
            // 
            // txtFinalAgirligi
            // 
            txtFinalAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalAgirligi.Location = new Point(421, 206);
            txtFinalAgirligi.Name = "txtFinalAgirligi";
            txtFinalAgirligi.Size = new Size(299, 28);
            txtFinalAgirligi.TabIndex = 20;
            // 
            // txtVizeAgirligi
            // 
            txtVizeAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeAgirligi.Location = new Point(81, 206);
            txtVizeAgirligi.Name = "txtVizeAgirligi";
            txtVizeAgirligi.Size = new Size(299, 28);
            txtVizeAgirligi.TabIndex = 19;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(530, 183);
            label4.Name = "label4";
            label4.Size = new Size(102, 20);
            label4.TabIndex = 18;
            label4.Text = "Final Ağırlığı:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(176, 183);
            label3.Name = "label3";
            label3.Size = new Size(98, 20);
            label3.TabIndex = 17;
            label3.Text = "Vize Ağırlığı:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(530, 38);
            label2.Name = "label2";
            label2.Size = new Size(89, 20);
            label2.TabIndex = 16;
            label2.Text = "Final Notu:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(158, 38);
            label1.Name = "label1";
            label1.Size = new Size(153, 20);
            label1.TabIndex = 15;
            label1.Text = "Vize (Sunum) Notu:";
            // 
            // txtFinalNotu
            // 
            txtFinalNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalNotu.Location = new Point(421, 61);
            txtFinalNotu.Name = "txtFinalNotu";
            txtFinalNotu.Size = new Size(299, 28);
            txtFinalNotu.TabIndex = 14;
            // 
            // txtVizeNotu
            // 
            txtVizeNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeNotu.Location = new Point(81, 61);
            txtVizeNotu.Name = "txtVizeNotu";
            txtVizeNotu.Size = new Size(299, 28);
            txtVizeNotu.TabIndex = 13;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(329, 20);
            label5.TabIndex = 26;
            label5.Text = "TUR 101 (1) 1.0 Türk Dili I dersini seçtiniz.";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(lblYukseltmeDurumu);
            Controls.Add(lblGeçmeDurumu);
            Controls.Add(lblHarfNotu);
            Controls.Add(lblAGNO);
            Controls.Add(btnHesapla);
            Controls.Add(txtFinalAgirligi);
            Controls.Add(txtVizeAgirligi);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtFinalNotu);
            Controls.Add(txtVizeNotu);
            MaximizeBox = false;
            Name = "Form6";
            Text = "Seçilen Ders";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblYukseltmeDurumu;
        private Label lblGeçmeDurumu;
        private Label lblHarfNotu;
        private Label lblAGNO;
        private Button btnHesapla;
        private TextBox txtFinalAgirligi;
        private TextBox txtVizeAgirligi;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtFinalNotu;
        private TextBox txtVizeNotu;
        private Label label5;
    }
}