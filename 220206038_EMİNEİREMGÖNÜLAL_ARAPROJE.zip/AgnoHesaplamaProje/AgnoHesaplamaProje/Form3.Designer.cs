﻿namespace AgnoHesaplamaProje
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtVizeNotu = new TextBox();
            txtFinalNotu = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtVizeAgirligi = new TextBox();
            txtFinalAgirligi = new TextBox();
            btnHesapla = new Button();
            lblAGNO = new Label();
            lblHarfNotu = new Label();
            lblGeçmeDurumu = new Label();
            lblYukseltmeDurumu = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // txtVizeNotu
            // 
            txtVizeNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeNotu.Location = new Point(80, 74);
            txtVizeNotu.Name = "txtVizeNotu";
            txtVizeNotu.Size = new Size(299, 28);
            txtVizeNotu.TabIndex = 0;
            // 
            // txtFinalNotu
            // 
            txtFinalNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalNotu.Location = new Point(420, 74);
            txtFinalNotu.Name = "txtFinalNotu";
            txtFinalNotu.Size = new Size(299, 28);
            txtFinalNotu.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(152, 51);
            label1.Name = "label1";
            label1.Size = new Size(153, 20);
            label1.TabIndex = 2;
            label1.Text = "Vize (Sunum) Notu:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(529, 51);
            label2.Name = "label2";
            label2.Size = new Size(89, 20);
            label2.TabIndex = 3;
            label2.Text = "Final Notu:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(175, 196);
            label3.Name = "label3";
            label3.Size = new Size(98, 20);
            label3.TabIndex = 4;
            label3.Text = "Vize Ağırlığı:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(529, 196);
            label4.Name = "label4";
            label4.Size = new Size(102, 20);
            label4.TabIndex = 5;
            label4.Text = "Final Ağırlığı:";
            // 
            // txtVizeAgirligi
            // 
            txtVizeAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVizeAgirligi.Location = new Point(80, 219);
            txtVizeAgirligi.Name = "txtVizeAgirligi";
            txtVizeAgirligi.Size = new Size(299, 28);
            txtVizeAgirligi.TabIndex = 6;
            // 
            // txtFinalAgirligi
            // 
            txtFinalAgirligi.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFinalAgirligi.Location = new Point(420, 219);
            txtFinalAgirligi.Name = "txtFinalAgirligi";
            txtFinalAgirligi.Size = new Size(299, 28);
            txtFinalAgirligi.TabIndex = 7;
            // 
            // btnHesapla
            // 
            btnHesapla.BackColor = Color.PowderBlue;
            btnHesapla.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnHesapla.Location = new Point(300, 268);
            btnHesapla.Name = "btnHesapla";
            btnHesapla.Size = new Size(191, 31);
            btnHesapla.TabIndex = 8;
            btnHesapla.Text = "Hesapla";
            btnHesapla.UseVisualStyleBackColor = false;
            btnHesapla.Click += btnHesapla_Click;
            // 
            // lblAGNO
            // 
            lblAGNO.AutoSize = true;
            lblAGNO.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblAGNO.Location = new Point(300, 314);
            lblAGNO.Name = "lblAGNO";
            lblAGNO.Size = new Size(105, 20);
            lblAGNO.TabIndex = 9;
            lblAGNO.Text = "Ders Agnosu:";
            // 
            // lblHarfNotu
            // 
            lblHarfNotu.AutoSize = true;
            lblHarfNotu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblHarfNotu.Location = new Point(300, 348);
            lblHarfNotu.Name = "lblHarfNotu";
            lblHarfNotu.Size = new Size(139, 20);
            lblHarfNotu.TabIndex = 10;
            lblHarfNotu.Text = "Dersin Harf Notu:";
            // 
            // lblGeçmeDurumu
            // 
            lblGeçmeDurumu.AutoSize = true;
            lblGeçmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblGeçmeDurumu.Location = new Point(300, 387);
            lblGeçmeDurumu.Name = "lblGeçmeDurumu";
            lblGeçmeDurumu.Size = new Size(118, 20);
            lblGeçmeDurumu.TabIndex = 11;
            lblGeçmeDurumu.Text = "Geçiş Durumu:";
            // 
            // lblYukseltmeDurumu
            // 
            lblYukseltmeDurumu.AutoSize = true;
            lblYukseltmeDurumu.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblYukseltmeDurumu.Location = new Point(300, 421);
            lblYukseltmeDurumu.Name = "lblYukseltmeDurumu";
            lblYukseltmeDurumu.Size = new Size(107, 20);
            lblYukseltmeDurumu.TabIndex = 12;
            lblYukseltmeDurumu.Text = "Bilgilendirme:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(488, 20);
            label5.TabIndex = 13;
            label5.Text = "ATA 101 (2) 1.0 Atatürk İlkeleri ve İnkılap Tarihi I dersini seçtiniz.";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(lblYukseltmeDurumu);
            Controls.Add(lblGeçmeDurumu);
            Controls.Add(lblHarfNotu);
            Controls.Add(lblAGNO);
            Controls.Add(btnHesapla);
            Controls.Add(txtFinalAgirligi);
            Controls.Add(txtVizeAgirligi);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtFinalNotu);
            Controls.Add(txtVizeNotu);
            MaximizeBox = false;
            Name = "Form3";
            Text = "Seçilen Ders";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtVizeNotu;
        private TextBox txtFinalNotu;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtVizeAgirligi;
        private TextBox txtFinalAgirligi;
        private Button btnHesapla;
        private Label lblAGNO;
        private Label lblHarfNotu;
        private Label lblGeçmeDurumu;
        private Label lblYukseltmeDurumu;
        private Label label5;
    }
}